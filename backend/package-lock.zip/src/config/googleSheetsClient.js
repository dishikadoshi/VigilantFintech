/**
 * googleSheetsClient.js
 * ───────────────────────
 * Replaces config/supabaseClient.js.
 *
 * Authenticates against the Google Sheets API using a Google Cloud
 * Service Account (server-to-server, no user OAuth flow needed).
 *
 * Setup (see GOOGLE_SHEETS_SETUP.md for full walkthrough):
 *   1. Create a Google Cloud project → enable "Google Sheets API".
 *   2. Create a Service Account → generate a JSON key.
 *   3. Share your Google Sheet with the service account's email
 *      (found in the JSON key as "client_email") — Editor access.
 *   4. Put the values in backend/.env:
 *        GOOGLE_SERVICE_ACCOUNT_EMAIL=xxx@xxx.iam.gserviceaccount.com
 *        GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
 *        GOOGLE_SHEET_ID=the-id-from-the-sheet-url
 */

const { google } = require('googleapis');

let _sheetsClient = null;

function getSpreadsheetId() {
  const id = process.env.GOOGLE_SHEET_ID;
  if (!id) throw new Error('GOOGLE_SHEET_ID is not set');
  return id;
}

/**
 * Returns an authenticated `sheets.spreadsheets.values` client.
 * Cached after first call (JWT auth client handles token refresh itself).
 */
function getSheetsClient() {
  if (_sheetsClient) return _sheetsClient;

  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  // Private keys are stored in .env with literal "\n" — convert back to real newlines.
  const rawKey = process.env.GOOGLE_PRIVATE_KEY;
  const key = rawKey ? rawKey.replace(/\\n/g, '\n') : undefined;

  if (!email) throw new Error('GOOGLE_SERVICE_ACCOUNT_EMAIL is not set');
  if (!key) throw new Error('GOOGLE_PRIVATE_KEY is not set');

  const auth = new google.auth.JWT({
    email,
    key,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });

  // Without an explicit timeout, a stalled token exchange or API call has
  // no timeout at all — the request just hangs until Vercel force-kills
  // the function (visible as a bare 504 with no useful error message).
  // 15s is generous for a same-region Google API call but still far under
  // any Vercel function's max duration, so a real failure surfaces as a
  // clear thrown error instead of a silent hang.
  _sheetsClient = google.sheets({ version: 'v4', auth, timeout: 15_000 });
  return _sheetsClient;
}

module.exports = { getSheetsClient, getSpreadsheetId };