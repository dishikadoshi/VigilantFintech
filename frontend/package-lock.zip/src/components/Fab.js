import React, { useEffect } from 'react';
import { whatsappHref, CAL } from '../config/site';
import { initCalEmbed, CAL_NAMESPACE } from '../utils/calEmbed';

const CalendarIcon = (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <rect x="3.5" y="5" width="17" height="15.5" rx="3" /><path d="M8 3v4M16 3v4M3.5 10h17" /><path d="m9.5 15 1.8 1.8 3.4-3.6" />
  </svg>
);

/**
 * Floating action buttons, stacked bottom-right:
 *   [ Book a meeting (Cal.com) ]   ← top
 *   [ WhatsApp ]                   ← bottom corner
 * WhatsApp is only rendered when a number is configured.
 */
export function WhatsAppFab() {
  const href = whatsappHref();
  if (!href) return null;
  return (
    <a className="fab" href={href} target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
        <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 0 0 4.74 1.21h.01c5.46 0 9.9-4.45 9.9-9.91A9.85 9.85 0 0 0 12.04 2zm0 18.15h-.01a8.2 8.2 0 0 1-4.18-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.24-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.22-8.23 8.22zm4.52-6.16c-.25-.12-1.47-.73-1.7-.82-.23-.08-.39-.12-.56.12-.17.25-.64.82-.78.98-.14.17-.29.19-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.23-.16-.48-.29z" />
      </svg>
    </a>
  );
}

// Opens Cal.com's own booking window (see utils/calEmbed.js). The
// data-cal-* attributes are what Cal.com's embed script listens for.
export function BookingFab() {
  useEffect(() => { initCalEmbed(); }, []);
  if (!CAL.link) {
    if (process.env.NODE_ENV !== 'production') console.warn('[Booking] REACT_APP_CAL_LINK is not set — the calendar icon is hidden. Add it to f/.env and restart `npm start`.');
    return null;
  }
  return (
    <button type="button" className="fab fab--book" aria-label="Book a meeting" aria-haspopup="dialog"
      data-cal-namespace={CAL_NAMESPACE} data-cal-link={CAL.link}
      data-cal-config={JSON.stringify({ layout: 'month_view', theme: CAL.theme })}>
      {CalendarIcon}
    </button>
  );
}

export function FabStack() {
  return (
    <div className="fabs">
      <BookingFab />
      <WhatsAppFab />
    </div>
  );
}
