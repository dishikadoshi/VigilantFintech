import React from 'react';
import { Page, PageHero } from '../components/ui';
import { PRIVACY, TERMS, COOKIES, UPDATED } from '../content/legal';

function Legal({ path, title, eyebrow, intro, sections }) {
  return (
    <Page path={path} title={title} description={`${title} — how we handle information, our commitments and your choices.`}>
      <PageHero eyebrow={eyebrow} title={title} sub={`Last updated: ${UPDATED}. ${intro}`} />
      <section className="legal">
        <div className="container legal__in">
          <nav className="legal__toc" aria-label="On this page">
            {sections.map((s, i) => <span key={s.h}>{String(i + 1).padStart(2, '0')} {s.h}</span>)}
          </nav>
          <div className="prose">
            {sections.map((s, i) => (
              <section key={s.h} data-reveal="up">
                <h2><em>{String(i + 1).padStart(2, '0')}</em>{s.h}</h2>
                {(s.p || []).map((t) => <p key={t}>{t}</p>)}
                {s.ul && <ul>{s.ul.map((t) => <li key={t}>{t}</li>)}</ul>}
              </section>
            ))}
          </div>
        </div>
      </section>
    </Page>
  );
}

export const PrivacyPolicy = () => (
  <Legal path="/privacy-policy" title="Privacy Policy" eyebrow="Legal" intro="How we collect, use and protect your information." sections={PRIVACY} />
);
export const Terms = () => (
  <Legal path="/terms-and-conditions" title="Terms & Conditions" eyebrow="Legal" intro="The terms that apply when you use this website." sections={TERMS} />
);
export const CookiePolicy = () => (
  <Legal path="/cookie-policy" title="Cookie Policy" eyebrow="Legal" intro="What this website stores in your browser." sections={COOKIES} />
);
